public class Math {
    public static int abs (int x) {
        return (x > 0 ? x : -x);
    }
}
